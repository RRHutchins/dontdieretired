---
title: "He started lifting at 70 to get ready for knee surgery. At 82 he holds a national record."
slug: ravi-sood-powerlifting-record-82
date: 2026-09-22
category: move
tags: [strength, beginner, competition, men, health]
segments: [restarter, mover]
hook: "Ravi Sood took up weightlifting at 70 to strengthen his legs before double knee replacement. At 82 he holds the Australian deadlift record for his class."
lesson: "Training for a medical reason — 'prehab' before surgery — can turn into a passion, and a national record."
standfirst: "The Canberra pensioner's surgeon told him that strong muscles would make his knee operations easier. He took the advice further than anyone expected."
summary: "Ravi Sood began weightlifting at 70 before double knee replacement surgery. At 82 he holds the Australian age-group deadlift record (115 kg) and was selected to represent Australia at the World Masters Powerlifting Championships."
try_this:
  - "If you have an operation or a diagnosis coming, ask your consultant one question: 'What exercise would make this go better?' Then do it."
  - "Book a single session with a physiotherapist or qualified trainer who works with over-60s and ask them to teach you three strength movements."
  - "Do those three movements twice this week. Write down the weight or the reps. Next week, add one."
sources:
  - {title: "Powerlifting champion, aged 82, ready to represent Australia", publisher: "ABC News (Australia)", date: "9 October 2025", url: "https://www.abc.net.au/news/2025-10-09/powerlifting-champion-aged-82-and-ready-to-represent-australia/105868066"}
---
Most people facing a double knee replacement in their seventies think about how to get through it. Ravi Sood, from Canberra, thought about how to get *ready* for it.

> "Both my knees needed replacing, and the orthopaedic surgeon said that if I had my muscles in good condition, the surgery would be easier."
> — Ravi Sood, ABC News

So, at 70, he started weightlifting. Twelve years later, at 82, he holds the Australian deadlift record for his age and weight class — 115 kilograms — and was selected to represent Australia at the World Masters Powerlifting Championships in South Africa.

> "This is my dream come true. Just the fact that I'm wearing Australian green and gold, for me, that's fantastic."

## "Prehab" is real, and under-used

Surgeons and physiotherapists have known for years that patients who go into joint surgery stronger come out of it faster. The idea has a name — prehabilitation — and it is one of the best-evidenced reasons for an older adult to start strength training. Stronger quadriceps and glutes mean a quicker return to walking, fewer complications and less time in rehab afterwards.

What Sood's story shows is what happens if you *don't stop* once the surgery is done. The habit that was meant to be a means to an end became the end itself.

## A note on motivation

Sood is not chasing medals.

> "I don't really care if I win any medals — just to represent my country at an international level, that's out of this world."

Notice the pattern across this week's stories. [Martine Barons](/stories/martine-barons-world-champion-deadlift-65/) talks about lifting grandchildren, not trophies. [Betty Brussel](/stories/betty-brussel-99-three-world-records/) talks about being with people. Sood talks about wearing the green and gold. None of them is motivated by the number on the bar. The number is a by-product of turning up.

## Why deadlifting suits older bodies

The deadlift — picking a weight up off the floor with a straight back and standing up — is the most functional lift there is. It is literally the movement of lifting a grandchild, a shopping bag or a suitcase. Done with good coaching and sensible loads:

- it strengthens the back, hips and legs together
- it improves grip strength, one of the best predictors of healthy ageing
- it loads the bones, which matters enormously for osteoporosis risk
- it is straightforward to progress: add a little weight, or a rep, each week

Sood started at 70 with a surgeon's suggestion and a pair of knees that needed replacing. If that is not permission to start, we are not sure what would be.
